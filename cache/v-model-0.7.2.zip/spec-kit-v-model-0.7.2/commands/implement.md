---
description: V-Model-aware implementation bridge — runs the pre-implementation gate, generates code and four-level tests with Implements directives, splices into existing sources via sentinel-managed regions, self-checks for hallucinated IDs, runs the quality harness, and emits an annotated commit plus a structured run summary.
handoffs:
  - label: Run V-Model Trace
    agent: speckit.v-model.trace
    prompt: Validate end-to-end traceability after implementation
    send: true
  - label: Re-Tasks
    agent: speckit.v-model.tasks
    prompt: Re-derive the V-Model task list if implementation surfaced new modules or hazards
scripts:
  sh: scripts/bash/setup-implement.sh --json --include-tasks
  ps: scripts/powershell/setup-implement.ps1 -Json -IncludeTasks
---

<!-- Implements: REQ-015, REQ-016, REQ-017, REQ-018, REQ-019, REQ-020, REQ-021, REQ-022, REQ-023, REQ-027, REQ-NF-002, REQ-NF-004, REQ-NF-005, REQ-CN-002, REQ-CN-003, REQ-CN-004, SYS-003, SYS-004, SYS-006, SYS-007, SYS-008, SYS-012, SYS-014, ARCH-004, ARCH-005, ARCH-006, ARCH-007, ARCH-009, ARCH-010, ARCH-011, ARCH-016, ARCH-017, ARCH-018, MOD-005, MOD-006, MOD-007, MOD-008, MOD-009, MOD-013, MOD-015, MOD-021, MOD-022, MOD-023, HAZ-007, HAZ-009, HAZ-014, HAZ-021, HAZ-023, HAZ-025, D-001, D-014 -->

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Goal

Generate **a fully working and validated implementation** of the software designed through the V-Model cycle, with full traceability from every emitted source file and test back to the V-Model identifier it satisfies. A complete V-Model specification goes in; working code and four-level tests come out; a single annotated commit records the chain.

The command reads all 8 V-Model artefacts directly from `FEATURE_DIR/v-model/` (per REQ-015): the four dev-side artefacts (`requirements.md`, `system-design.md`, `architecture-design.md`, `module-design.md`) drive *what to build*; the four test-side artefacts (`unit-test.md`, `integration-test.md`, `system-test.md`, `acceptance-plan.md`) drive *what "working" means*. Neither `plan.md` nor `tasks.md` is required — when present they enrich the run, but the V-Model artefacts are the source of truth.

The operative philosophy is **fail-fast**: the V-Model gate (ARCH-007) runs **before any codegen**, the hallucination guard (ARCH-009) runs **before any commit**, and either non-zero verdict aborts with an empty workspace and a populated `fatal_errors[]` (REQ-016, REQ-NF-004, REQ-CN-002, HAZ-007, HAZ-009). Code and tests are emitted with explicit `Implements: <ID>` traceability comments — these are the input to the guard, so the order is: generate → guard → commit, never any other permutation (REQ-018, REQ-019, REQ-023, D-004, D-008).

Modifications of pre-existing source files are **never** ad-hoc: every write goes through the sentinel-managed region splicer (ARCH-010, MOD-014), which atomically replaces only the bytes between `<!-- BEGIN MANAGED id="<region>" -->` and `<!-- END MANAGED id="<region>" -->` and refuses on unbalanced or overlapping markers (REQ-022, REQ-CN-003, REQ-CN-004, D-001, D-015, D-016, HAZ-014, HAZ-025).

**Missing V-Model artefacts are fatal, not graceful.** Any of the 8 V-Model artefacts absent ⇒ the command refuses, names every missing artefact in `fatal_errors[]`, exits non-zero. Partial implementation contradicts the "fully working and validated software" contract. `hazard-analysis.md` is the sole auxiliary exception — its absence is a warning.

On every exit path — success or failure — the structured run summary is flushed to stdout (REQ-027, ARCH-016, MOD-021, SYS-012). The paradigm remains Markdown prompt + shell + YAML; no new Python is introduced (D-001).

**Non-goals**: this command does NOT mutate any V-Model artefact, re-run hazard analysis, regenerate the traceability matrix, or rewrite `tasks.md`. It is a code generator over the V-Model artefact set.

## Execution Steps

### 1. Setup

Run `{SCRIPT}` from the repository root and parse the JSON output. Required keys: `FEATURE_DIR`, `AVAILABLE_DOCS`, `BRANCH`. The V-Model directory is `FEATURE_DIR/v-model/` (may be absent on greenfield features).

Also derive `REPO_ROOT="$(git rev-parse --show-toplevel)"` for use by Step 7 — the bridge wrapper's JSON does not currently surface `REPO_ROOT` (the upstream `check-prerequisites.sh` only includes it under `--paths-only`), so the command itself resolves it via git for the hallucination-guard scope.

For single quotes in args like "I'm Groot", use escape syntax: e.g 'I'\''m Groot' (or double-quote if possible: "I'm Groot").

Read `.specify/memory/constitution.md`. Read `FEATURE_DIR/spec.md`, every doc named in `AVAILABLE_DOCS` (`data-model.md`, `contracts/`, `research.md`, `quickstart.md`), and `FEATURE_DIR/plan.md` and `FEATURE_DIR/tasks.md` if present (both are OPTIONAL enrichment — when produced by `/speckit.v-model.plan` / `/speckit.v-model.tasks` they provide additional context, but neither is the authoritative iteration source for code generation per REQ-015 / MOD-005).

Read **every** V-Model artefact in `FEATURE_DIR/v-model/` natively as Markdown — no parser is shipped. Record the read set as `inputs_read[]`. **All 8 V-Model artefacts are required** for this command:

- **Dev-side (high-level → detailed):** `requirements.md` anchors the verifiable intent; `system-design.md` supplies system decomposition and operational states; `architecture-design.md` supplies module boundaries and interface contracts; `module-design.md` supplies algorithms, data structures, and Target Source Files.
- **Test-side (the validation documents that define "working"):** `acceptance-plan.md`, `system-test.md`, `integration-test.md`, `unit-test.md` — every level of the V has a paired validation document, and the generated code MUST be compliant with all four.

`hazard-analysis.md` is auxiliary but recommended; its absence is logged as a `warnings[]` entry and does not block the run.

**Refuse to proceed** if any of the 8 V-Model artefacts is absent or unparseable: emit §Structured Summary with `fatal_errors[]` naming every missing artefact, exit 1. Partial implementation contradicts the "fully working and validated software" contract that defines this command's purpose.

### 2. Pre-implementation gate (per ARCH-007, MOD-010 → T008, REQ-016, REQ-NF-004, REQ-CN-002, D-003)

Invoke the gate wrapper (reusing the script delivered in Step B.2 / T008):

```bash
bash scripts/bash/run-v-model-gate.sh "$FEATURE_DIR"
```

The wrapper concatenates `build-matrix.sh` + the five `validate-*-coverage.sh` scripts (D-003) and terminates stdout with exactly `GATE: PASS` or `GATE: FAIL`.

- `GATE: FAIL` ⇒ append the wrapper's stdout into `fatal_errors[]`, emit §Structured Summary, exit 1. **No code generation runs.** (HAZ-009 false-negative-gate and HAZ-010 false-positive-gate are jointly mitigated by reusing the validated inner scripts.)
- `GATE: PASS` ⇒ proceed to Step 3.

### 3. Domain overlay (per ARCH-011, MOD-015, REQ-024)

If `v-model-config.yml` exists at the repository root, parse its `domain:` value (e.g. `iso_26262`, `do_178c`, `iec_62304`) and load any prompt augmentation under `overlays/<domain>/`. See `v-model-config.yml.example` at the repository root for the canonical schema; valid values match the directory names under `commands/overlays/`. Augmentation is **purely additive** — base instructions for §Code Generation and §Test Generation are NEVER overridden (ARCH-011, MOD-015 = Domain Overlay Adapter; cf. SYS-008).

A malformed `v-model-config.yml` (unparseable YAML, missing `domain:` key, or the named overlay directory is absent) is fail-closed: append the parser stderr to `fatal_errors[]`, emit §Structured Summary, exit 1. Absence of the file is normal — base behaviour applies.

### 4. Code generation (per ARCH-005, MOD-006, MOD-007, REQ-018, REQ-019)

**Iteration source: `module-design.md`.** For each `MOD-NNN` row (skipping rows marked `[DEPRECATED]` or classified `DROP-recharacterized`) — one code-generation unit per MOD entry. `tasks.md`, when present, serves only as supplemental ordering / parallelisation context; it is not the iteration source.

**Generation inputs (all consulted per MOD):** code generation is informed by the full V-Model artefact set. For each MOD, the generated code MUST simultaneously satisfy:

- **`module-design.md`** (the MOD entry itself) — algorithm, data structures, error handling, Target Source File, target language.
- **`unit-test.md`** (test-first discipline) — the `UTP-NNN` / `UTS-NNN-XN` cases scoped to this MOD define the verifiable behavior the generated code MUST exhibit. The tests are already specified; the code is written to make them pass.
- **`architecture-design.md`** — the parent `ARCH-NNN` module's Interface contract (error codes, data formats, module boundaries) the code MUST honor.
- **`system-design.md`** — system-level context (operational states, data design, system decomposition) the code MUST fit within.
- **`requirements.md`** — the parent `REQ-NNN` (functional, non-functional, interface, constraint) intent the MOD ultimately satisfies. Code MUST be compliant with every cited requirement.
- **`integration-test.md`, `system-test.md`, `acceptance-plan.md`** — describe higher-level behaviors the MOD's interfaces participate in; the code MUST be compatible with these test scenarios.

**Per-MOD generation steps:**

1. Resolve the Target Source File and target language declared in the MOD row.
2. Render the module body so it (a) implements the MOD's specified algorithm / data structures; (b) makes the corresponding `UTP-NNN` / `UTS-NNN-XN` cases pass (test-first); (c) honors the parent `ARCH-NNN` interface contract; (d) fits the system-level context; (e) satisfies the parent `REQ-NNN` intent; (f) applies any §Domain Overlay augmentation.
3. Emit a language-appropriate `Implements: <ID, ID, …>` header comment listing every V-Model ID the file satisfies — at minimum the `MOD-NNN` and its parent `ARCH-NNN`; per public symbol, attach an additional `Implements: <ID>` line per REQ-019 / SCN-019-A1.

These `Implements:` comments are the **sole** input to the hallucination guard in Step 7 — every cited ID must already exist in the V-Model artefact set or the guard will reject the change (REQ-023, REQ-NF-002, MOD-013, MOD-025).

### 5. Four-level test generation (per ARCH-006, MOD-008, MOD-009, REQ-020, SYS-003)

Emit tests at **all four V-Model levels** into the project's existing test directories:

- **Unit** (`tests/unit/`) — one or more files per `UTP-NNN` / `UTS-NNN-XN` in `unit-test.md`.
- **Integration** (`tests/integration/`) — per `ITP-NNN` / `ITS-NNN-XN` in `integration-test.md`.
- **System** (`tests/system/`) — per `STP-NNN` / `STS-NNN-XN` in `system-test.md`.
- **Acceptance** (`tests/acceptance/`) — per `ATP-NNN` / `SCN-NNN-XN` in `acceptance-plan.md`.

Each generated test carries the same `Implements: <UTP|ITP|STP|ATP|SCN-NNN, …>` directive convention as Step 4. **At least one file MUST appear under each of the four directories on the success path** per SCN-020-A1 — all four test plans are mandatory inputs (Step 1) and produce mandatory outputs.

A test-plan artefact that is present but fails to parse is fail-closed: append the parser diagnostic to `fatal_errors[]`, emit §Structured Summary, exit 1 (ARCH-006 error path).

### 6. Sentinel-managed splicing into existing sources (per ARCH-010, REQ-022, REQ-CN-003, REQ-CN-004, REQ-NF-005, D-001, D-015, D-016)

For any modification of a **pre-existing** source file (Steps 4 and 5 above, when the target file already exists on disk), use the splicer delivered in Step B.2 / T010 (hardened in Step C.5 / MF-5) — never write the whole file. Two invocation modes are supported:

**Single-region mode (legacy positional)** — use when only one MANAGED region in the target needs replacement, or when every region in the target should receive the same payload:

```bash
bash scripts/bash/splice-managed-regions.sh \
    "<target-file>" "<generated-region-file>" "<language>"
```

**Per-region mode (`--region-from`, RECOMMENDED for multi-region targets)** — use when Steps 4/5 emit multiple `Implements:` regions that all land in the same source file. Build a regions file with one `<<<REGION id="…">>> … <<<END>>>` block per id and pass it via `--region-from`:

```bash
bash scripts/bash/splice-managed-regions.sh \
    --region-from "<regions-file>" "<target-file>" "<language>"
```

The script writes the spliced content to **stdout only**; the **caller** is responsible for the atomic-rename idiom (D-016, REQ-NF-005, MOD-002 — the same `mktemp` + `mv` pattern enforced in `commands/plan.md` Step 4):

```bash
tmp=$(mktemp -p "$(dirname "$target")")
bash scripts/bash/splice-managed-regions.sh "$target" "$gen" "$lang" > "$tmp" \
    2>> tests/.splicer-diffs.log
mv "$tmp" "$target"
```

On every successful run with a non-empty diff, the splicer emits `diff -u <target> <spliced>` on **stderr** for audit-trail purposes (MF-5). Tee to `tests/.splicer-diffs.log` (or any workspace log) to capture the byte-level evidence of what was changed; no-op runs (idempotent re-splice, sentinel-free target) emit nothing on stderr so the pass-through path stays clean.

Marker grammar per D-015: `<!-- BEGIN MANAGED id="<region>" -->` / `<!-- END MANAGED id="<region>" -->` (or the language-equivalent comment syntax — `# … #`, `// … //`). Exit-code grammar (HAZ-025) distinguishes corruption-class errors from input-class errors:

- **Exit 1** — file-not-found, unbalanced/orphan/nested MANAGED markers, bad CLI usage.
- **Exit 2** — hardening violations (MF-5): BEGIN/END id-mismatch (HAZ-014 region-marker corruption from copy-paste), duplicate region id within a target (HAZ-007), missing payload for a target region under `--region-from`, or a malformed regions file (unbalanced or duplicate `<<<REGION>>>` ids).

On any non-zero exit the splicer **leaves the original file untouched** (validation is fail-fast and the `mktemp + mv` envelope only commits on exit 0). Propagate the diagnostic into `fatal_errors[]`, emit §Structured Summary, exit 1. **Never write to `/tmp`** — the `-p "$(dirname "$target")"` argument keeps the temporary file on the same filesystem as its destination.

Code outside the managed region must remain byte-identical (ATP-022-A). This is the SOLE concurrency safeguard delivered for pre-existing sources in v0.7.0 — process-wide locking is deferred (SYS-007 / SYS-015 §Risk Note).

### 7. Hallucination-guard self-check (per ARCH-009, MOD-013, REQ-023, REQ-NF-002, D-004, D-008)

Invoke the guard wrapper (reusing the script delivered in Step B.2 / T009 and extended in Step C.4) over the **repo root** after Steps 4–6 have written every generated and spliced file:

```bash
bash scripts/bash/validate-implements-ids.sh \
  --canonical "$FEATURE_DIR/v-model" \
  --scan "$REPO_ROOT" \
  --changed-only
```

The script greps the canonical V-Model ID set out of `<FEATURE_DIR>/v-model/*.md`, then scans every file modified or added by the current change-set (`git diff` HEAD ∪ staged ∪ untracked-new, intersected with `--scan`, excluding paths under `--canonical`) for `Implements: <ID>` (and language-equivalent) comments, printing `<file>:<line>: unknown id <id>` for every offence and terminating with exactly `GUARD: PASS` or `GUARD: FAIL`. Scanning the repo root rather than `$FEATURE_DIR` is what brings the actually-generated source under `src/`, `tests/unit/`, `tests/integration/`, `tests/system/`, and `tests/acceptance/` into scope (these live OUTSIDE `$FEATURE_DIR`); `--changed-only` keeps the gate fast and focused on this run's deltas. The reduced-enrichment / D-014 fallback in Step 9 still applies — the guard remains a hard gate regardless. There is no LLM in this loop — determinism is the contract (Constitution Principle II; D-004).

- `GUARD: FAIL` ⇒ STOP. Append the offending lines into `fatal_errors[]`, emit §Structured Summary, exit 1. **Do NOT commit.** This guards HAZ-007 (hallucinated `Implements` directive), HAZ-012 (false-negative), and HAZ-023 (stale snapshot — mitigated by running the guard immediately before Step 9, never earlier).
- `GUARD: PASS` ⇒ proceed to Step 8.

### 8. Quality / compliance harness (per ARCH-017, MOD-022, REQ-CN-003, REQ-CN-004)

Run the project's existing four-stack harnesses; do not introduce new tooling:

1. `bash tests/bats/run-bats.sh` (or the project's BATS entry).
2. `bash tests/pester/run-pester.sh` when the PowerShell stack is present.
3. `bash tests/evals/structural-eval.sh` (pytest-driven structural eval).
4. `bash tests/evals/llm-eval.sh` (DeepEval LLM eval).

Aggregate exit codes; any non-zero ⇒ append the failing harness summary into `fatal_errors[]`, emit §Structured Summary, **block the commit**, exit 1 (ARCH-017 merge-gate). The sole escape hatch is an explicit `--allow-failing-quality` argument on the `$ARGUMENTS` line; if present, downgrade the failure to a `warnings[]` entry and record the override under `risk_acceptances[]` of the §Structured Summary so the bypass is auditable (HAZ-021 — coverage-gate-not-enforced).

### 9. Commit annotation (per ARCH-018, MOD-023, REQ-021, REQ-NF-005)

**Commit subject grammar (non-negotiable)** — the prepared commit subject MUST conform to:

```
<base-subject> — <ID>[, <ID>]*
```

Where:
- `<base-subject>` is the conventional spec-kit-core commit subject (≤72 chars before the em-dash); use Conventional Commits style if the repo already does (`feat(<scope>): <imperative>` etc.).
- The separator is a literal **em-dash surrounded by single ASCII spaces** — `U+2014` — NOT `--`, NOT `-` (hyphen-minus), NOT `–` (U+2013 en-dash).
- The ID list is **comma-and-space-separated** (`, `), in the order the IDs appear in the in-context generation plan (MOD-023). Each ID MUST satisfy the canonical regex enforced by `validate-implements-ids.sh` and `tests/conftest.py`: `(?:REQ|SYS|ARCH|MOD|ITP|ITS|UTP|UTS|STP|STS|ATP|SCN|HAZ)(?:-[A-Z]{2,3})?-\d+(?:-[A-Z]\d*)?` plus `D-\d+`. The optional `(?:-[A-Z]{2,3})?` sub-prefix slot accepts derived-category IDs like `REQ-NF`, `REQ-CN`, `REQ-IF`, `REQ-DR`, `REQ-LC`, `REQ-SEC`, `SYS-DR`, `ATP-NF`, `SCN-LC`, etc.
- Empty ID list ⇒ omit the em-dash and the suffix entirely; record `warnings: ["empty implements list — commit subject not annotated"]` in §Structured Summary (Step 10) and emit the unannotated base subject (best-effort per ATP-021-A).

Precondition: Step 7 emitted `GUARD: PASS` and Step 8 emitted `quality: PASS` (or recorded an explicit `--allow-failing-quality` risk acceptance).

Construct the commit subject as the conventional spec-kit-core base message followed by an em-dash and a comma-separated list of every V-Model ID fulfilled by the change, derived from the in-context generation plan (MOD-023):

```
<base-message> — <ID>, <ID>, …
```

The body lists files modified, levels generated (U / I / S / A counts), gate verdict, guard verdict, and any active fallbacks.

**The prepared subject MUST be echoed verbatim into §Structured Summary as the labeled field `commit_subject:` (Step 10) on every exit path** — success, failure, dry-run, or empty-diff — so downstream consumers (CI parsers, audit tooling, the commit-suffix eval at `tests/evals/test_commit_suffix.py`) can extract it deterministically without parsing prose. This is the machine-extractability contract for ARCH-016 / MOD-021.

Issue `git commit -m "<message>"`. A `git commit` non-zero is fatal: append stderr to `fatal_errors[]`, emit §Structured Summary, exit 1.

### 10. Structured Summary (per ARCH-016, MOD-021, SYS-012, REQ-027)

On every exit path (success **and** failure), flush stdout and emit:

```
--- v-model implement summary ---
branch: <name>
feature: <id>
inputs_read:
  - <path>
artifacts_skipped:
  - <name>
gate: PASS | FAIL (<details if FAIL>)
codegen: <N> source files, <M> lines
testgen: UTP=<n> (tests/unit/), ITP=<n> (tests/integration/), STP=<n> (tests/system/), ATP=<n> (tests/acceptance/)
splice: <N> regions updated across <M> files
guard: PASS | FAIL (<details if FAIL>)
quality: PASS | FAIL (<harness summary>)
risk_acceptances:
  - <text>          # omit key when empty
warnings:
  - <text>
fatal_errors:
  - <text>          # omit key on success
commit_subject: <base-subject> — <ID>, <ID>, …
commit: <SHA> | <skipped — reason>
fallbacks: <list, or "none">
--- end summary ---
```

The `commit_subject:` field is the machine-extractable mirror of the prepared commit subject from Step 10 (ARCH-018, MOD-023, REQ-021). It MUST be present on **every** exit path — success, gate-fail, guard-fail, quality-fail, dry-run, empty-diff — so downstream eval and audit tooling never has to parse prose to recover the planned subject. Record the unannotated base subject when the ID list is empty and surface that in `warnings[]`. The em-dash MUST be the literal `U+2014` and the ID separator MUST be `, ` per the grammar block in Step 10.

This block is the contract for downstream consumers — CI parsers, the `v-model.trace` bridge, audit tooling. Truncation is itself a hazard (HAZ-025 mitigation).

### 11. Handoffs

On success, recommend `/speckit.v-model.trace` to validate the full upstream-to-downstream trace after implementation. The frontmatter's secondary handoff exposes a re-tasks path for when implementation surfaced new modules or hazards.

## Quality criteria

Self-check **every** invariant below; any violation forces re-emission with the offending step's `fatal_errors[]` populated:

- The pre-implementation gate (Step 2) ran and emitted `GATE: PASS` **before** any byte of code or test was generated (REQ-016, ARCH-007, MOD-005).
- The hallucination guard (Step 7) ran and emitted `GUARD: PASS` **before** any `git commit` was issued (REQ-023, ARCH-009, MOD-013).
- Every generated source and test file carries an `Implements: <ID, …>` header naming ≥1 V-Model ID; every public symbol additionally carries an `Implements: <ID>` comment per REQ-019.
- Every modification of a pre-existing source went through `splice-managed-regions.sh` and the caller's `mktemp` + `mv` atomic-rename idiom; **no write touched `/tmp`** (REQ-CN-003, REQ-CN-004, REQ-NF-005, D-016).
- Tests appear at all four V-Model levels (U / I / S / A); a missing test plan is fatal at Step 1 — all four test-side artefacts are required inputs, never gracefully skipped (REQ-020, SYS-003, REQ-NF-005B).
- The §Structured Summary is flushed on success **and** every failure exit path; `fatal_errors[]` is empty on success and present-with-content on every failure (REQ-027, MOD-021, SYS-012, HAZ-025).
- No fabricated V-Model identifiers appear anywhere in generated content — every cited ID is grep-resolvable in `FEATURE_DIR/v-model/` (REQ-NF-002, MOD-013, HAZ-007).
- The commit subject matches the `<base> — <ID>, <ID>, …` regex on the success path, or carries the documented unannotated-warning entry (REQ-021, ARCH-018, MOD-023).

## Failure modes & recovery

| Failure | Detection | User-facing recovery |
|---|---|---|
| Any of the 8 V-Model artefacts missing/unparseable | Step 1 read | `fatal_errors[]` naming every missing artefact, exit 1; user creates or completes the missing artefact(s) via the corresponding `/speckit.v-model.<level>` command (e.g. `/speckit.v-model.requirements`, `/speckit.v-model.module-design`, `/speckit.v-model.unit-test`) before re-running (REQ-NF-005B). |
| `GATE: FAIL` from `run-v-model-gate.sh` | Step 2 | Append wrapper stdout to `fatal_errors[]`; **no codegen**; exit 1; user closes the missing-coverage rows reported by the inner validators (HAZ-009, HAZ-010). |
| `v-model-config.yml` malformed | Step 3 parse | Fail-closed; exit 1; user fixes the YAML or removes the file (ARCH-011). |
| Test-plan artefact present but unparseable | Step 5 parse | `fatal_errors: ["<artefact> unparseable"]`, exit 1; user repairs the plan (ARCH-006). |
| Splicer reports unbalanced/overlapping markers | Step 6 | Original file untouched (script writes to stdout only); propagate stderr diff into `fatal_errors[]`, exit 1; user repairs the markers (HAZ-014, HAZ-025, D-015). |
| Atomic-rename failure (disk full, permissions) | `mv` non-zero in Step 6 | `fatal_errors: ["write failed: <path>"]`, exit 1; no partial file remains (REQ-NF-005, D-016, HAZ-014). |
| `GUARD: FAIL` from `validate-implements-ids.sh` | Step 7 | Append offending `<file>:<line>: unknown id <id>` lines to `fatal_errors[]`; **no commit**; exit 1; user removes or corrects the hallucinated IDs (HAZ-007, HAZ-012, HAZ-023). |
| Quality harness <100% (no override) | Step 8 | `fatal_errors[]` populated with the failing harness summary; commit blocked; exit 1 (ARCH-017, HAZ-021). |
| Quality harness <100% with `--allow-failing-quality` | Step 8 + arg parse | Downgrade to `warnings[]`; record under `risk_acceptances[]`; proceed; commit subject body annotates the override (HAZ-021 explicit acceptance). |
| `hazard-analysis.md` missing (auxiliary only) | Step 1 read | `warnings[]` entry naming the missing auxiliary; run proceeds. `hazard-analysis.md` is the sole non-blocking V-Model input. |
| `git commit` non-zero | Step 9 | `fatal_errors: ["git commit failed: <stderr>"]`, exit 1; user resolves the staging-area or hook failure (ARCH-018). |
| Partial codegen interrupted (signal, OOM) | post-mortem | Re-run is idempotent: gate re-evaluates, splicer regenerates only the managed regions, guard re-validates; commit will only annotate IDs from the completed run (D-016, ARCH-010). |
| §Structured Summary truncated | Step 10 flush failure | Last-resort: emit `--- v-model implement summary --- fatal_errors: [summary truncated] --- end summary ---`; exit 1 (HAZ-025, MOD-021). |

## Operating Constraints

### Additive-only modification of pre-existing sources

Pre-existing source files are mutated **only** between sentinel markers via `splice-managed-regions.sh`. Lines outside the managed region are byte-identical pre/post (REQ-022, REQ-CN-003, REQ-CN-004, ARCH-010, D-015).

### Fail-fast ordering

Gate before codegen; guard before commit. Either non-zero is a hard exit with `fatal_errors[]` populated and an empty workspace beyond what the gate had read (REQ-016, REQ-023, ARCH-007, ARCH-009, HAZ-007, HAZ-009).

### Atomic writes; never `/tmp`

Every write to disk uses the inline `mktemp -p "$(dirname "$f")"` + `mv` idiom on the same filesystem as the destination. No path under `/tmp` is ever opened for write (REQ-NF-005, D-016).

### Stateless re-runnability

Every run regenerates outputs from the V-Model artefact set (optionally enriched by `tasks.md` when present); there is no cache. Sentinel-managed splicing (D-015, D-016) and the `Implements: <ID>` directive convention together make re-runs idempotent: a no-op input produces a no-op commit (`git commit` exits non-zero on an empty diff and the structured summary records `commit: skipped — empty diff` as a warning, not a fatal error). The paradigm remains Markdown prompt + shell + YAML; no new Python is introduced (D-001).
