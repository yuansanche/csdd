# Standalone Usage Guide

Architecture Guard is an SDD-agnostic governance command installer. Install it once, then install the agent-native commands you want into a project using Spec Kit, OpenSpec, or a generic workflow.

## 1. Install

```bash
npx architecture-guard
```

Or install globally:

```bash
npm install -g architecture-guard
architecture-guard
```

The installer runs interactively and asks three questions. The installer uses `@inquirer/prompts`. Installed commands are Markdown or skills, but lean installs require a callable `architecture-guard` CLI for resource resolution and CLI-backed hygiene; use `--vendor` to copy static engine resources under `.architecture-guard` and avoid bundled-resource lookup for those assets.

## 2. Choose Your AI Agent

You will see a list of 35+ supported AI agents. Pick one or more:

```
Select AI agent(s) to install commands for:
  1. agy
  2. amp
  ...
  24. opencode
  ...
  35. zed
```

Enter numbers separated by commas (e.g. `24` for OpenCode) or type `all`.
Architecture Guard writes `ag-*` governance commands in each agent's native format:

| Agent | Format | Directory |
| :--- | :--- | :--- |
| OpenCode, Junie, Amp, CodeBuddy, Forge, Cursor, etc. | `.md` | `.opencode/commands/`, `.cursor/skills/`, ... |
| Claude Code, Devin, Rovodev, etc. | `SKILL.md` | `.claude/skills/ag-{cmd}/SKILL.md` |
| Gemini CLI, Tabnine | `.toml` | `.gemini/commands/`, `.tabnine/agent/commands/` |
| Goose | `.yaml` | `.goose/recipes/` |

## 3. Choose Your SDD Tool

```
Select SDD tool or workflow:
  1. spec-kit
  2. openspec
  3. none (generic Markdown workflow)
```

Architecture Guard uses the adapter selected during CLI initialization:

| SDD Tool or Workflow | Detection Marker | Works When |
| :--- | :--- | :--- |
| **SpecKit** | `.specify/` directory exists | Legacy SpecKit projects, `extension.yml` installs |
| **OpenSpec** | `openspec/config.yaml` or `openspec/` exists | OpenSpec projects |
| **Generic** | No known markers, or user declines | Any project |

The selected adapter is persisted in `.architecture-guard/selected-adapter` and loaded at the start of every orchestration command. Filesystem markers are inspected only when no selection exists. If both markers exist during first-time initialization, the user must choose an adapter.

Override the persisted adapter for one installed command with its `--adapter` input (this is not an `architecture-guard init` option), or change the persisted selection by rerunning the CLI installer with a new `--framework`.

## 4. Choose Your Commands

Pick from 20 governance commands:

| Command | When |
| :--- | :--- |
| `init` | Greenfield project setup — creates constitutions |
| `init-brownfield` | Existing codebase — maps current state first |
| `governed-discover` | Idea-stage — shape raw requests into spec-ready direction |
| `governed-spec` | Specification — generate and clarify specs |
| `governed-plan` | Planning — technical plan against architecture rules |
| `governed-tasks` | Task — generate tasks, analyze gaps |
| `governed-delivery` | Delivery — full plan → tasks → analyse pipeline |
| `governed-delivery-team` | Team delivery — approved User Story, plan, and tasks |
| `governed-implement` | Implement — apply tasks, then review |
| `review-artifacts` | Review artifacts — boundary drift, DRY violations, and hygiene |
| `review-implementation` | Review implementation — security and architecture findings |
| `review-pr` | Review someone else's pull request on any code host — drafts the review, posts only when you choose |
| `pr-feedback` | Work through review feedback on your own pull request — triage, fix, reply, and optionally resolve, with approval at each step |
| `verify` | Final validation — tasks vs code evidence |
| `apply` | Apply approved refactors into plans/tasks |
| `workflow` | End-to-end review across all workflow phases |
| `violation-detection` | Detect architecture drift invariants |
| `refactor-generator` | Turn violations into structured refactor tasks |
| `consolidate-specs` | Budgeted/offline spec index (optional) |
| `governed-archive` | Archive — verify, then finalize a completed feature |

You can select one, several, or `all`. The `review` alias selects `review-artifacts` and `review-implementation`, and the `pr` alias selects the pull-request skills; the installer writes only the commands you pick.

## 5. What Gets Installed

After you select agents, an SDD tool or workflow, and commands, `architecture-guard init` writes:

- **Command files** in your agent's directory (markdown, skill, TOML, or YAML)
- **Adapters** — `.architecture-guard/adapters/`: `resolve.md`, the built-in `spec-kit.md`, `openspec.md`, and `generic.md` (refreshed on every install), plus any custom adapters you add (never overwritten)
- **Runtime resources** — lean installs resolve bundled templates, presets, hygiene rules, and Sonar rules through the CLI; `--vendor` copies them under `.architecture-guard/`
- **AGENTS.md managed Architecture Guard section** — created or updated by init

## 6. Using the Installed Commands

After installation, invoke the agent-native command:

```
ag-review-artifacts
```

Or use the slash command registered by your agent:

```
ag-review-artifacts
```

The agent command detects the persisted SDD adapter, loads its path and command map, resolves engine resources through the `architecture-guard` CLI in lean mode, and runs the governance workflow in your project context. `architecture-guard` does not execute governance workflows itself; its `resolve` and `hygiene` subcommands provide runtime resources and checks requested by installed prompts.

## 7. Non-Interactive / CI Usage

For CI pipelines, `init` runs without prompts through `--yes`:

```bash
architecture-guard init . --yes --agent opencode --framework openspec --commands init,review
```

With `--yes`:
- Existing files: **replaced** by default (idempotent CI runs). Set `--overwrite keep-both` to preserve.
- `AGENTS.md` rules: the managed Architecture Guard section is updated in place; unrelated guidance is preserved.

Flags:

| Flag | Value | Description |
| :--- | :--- | :--- |
| `--yes` | (none) | Skip prompts; provide `--agent` and `--framework` unless the framework is auto-detected. |
| `--agent` | `opencode,claude` | Comma-separated agent keys |
| `--framework` | `spec-kit \| openspec \| none` | Framework to target |
| `--commands` | `all`, `review`, or `init,governed-plan` | Comma-separated canonical names, indices, or aliases |
| `--overwrite` | `replace` (default) / `skip` / `keep-both` | Existing file policy with `--yes` |
| `--claude-agent-teams` | (none) | Enable Claude Code Agent Teams (Beta / Experimental) |

Positional target:

```bash
architecture-guard init /path/to/project --yes --agent claude --framework openspec --commands init
```

The target argument specifies which directory to install into (default: current directory).

## 8. SDD Adapter Resolution in Practice

When an orchestration command runs, it:

1. Reads `.architecture-guard/adapters/resolve.md` and loads the persisted adapter selection
2. Loads `.architecture-guard/adapters/{name}.md` — the built-in or custom adapter for that SDD tool (see [ADAPTERS.md](../ADAPTERS.md#custom-adapters) for writing your own)
3. Resolves every `{adapter_path:key}` and `{adapter_command:key}` from the adapter
4. Executes the command body using adapter-resolved paths and commands

The same orchestration command `governed-spec` creates:

- SpecKit project: `specs/<feature>/spec.md` via `/speckit.specify`
- OpenSpec project: `openspec/changes/{change}/specs/{capability}/spec.md` via `openspec new change` + inline spec writes

You choose the SDD tool once; Architecture Guard adapts the rest.

## 9. Cross-Tool Upgrade

SpecKit user switching to OpenSpec:

1. Rerun `architecture-guard init` in the project — choose `openspec`
2. Architecture Guard writes the OpenSpec adapter and command files
3. The OpenSpec adapter reads SpecKit constitutions and proposes OpenSpec config.yaml equivalents during `init`
4. Original `commands/*.md` remain untouched; original SpecKit format path stays workable in parallel

## 10. Next Steps

- Full adapter contract reference: [ADAPTERS.md](../ADAPTERS.md)
- OpenSpec integration guide: [OPENSPEC-INTEGRATION.md](../OPENSPEC-INTEGRATION.md)
- Spec Kit integration guide: [SPECKIT-INTEGRATION.md](../SPECKIT-INTEGRATION.md)
- Governance workflows: [workflows.md](workflows.md)
- Beginner guide: [beginner-guide.md](beginner-guide.md)
