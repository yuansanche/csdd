---
description: Initialize or refine the project governance and architecture constitutions for Architecture Guard.
---

# Purpose

## Ponytail Core Contract

Before continuing, you **MUST** read and apply `.specify/extensions/architecture-guard/templates/ponytail_core.md` (or `templates/ponytail_core.md` in the extension source checkout) as the authoritative shared contract. Phase instructions may narrow but not weaken its safety or verification floor.

## Capability Composition

Read and apply `.specify/extensions/architecture-guard/templates/capability_composition.md` (or `templates/capability_composition.md` in the extension source checkout) before delegating to another Architecture Guard capability. Resolve and read the installed sibling skill or command file directly; do not treat a capability name, slash-command spelling, or Markdown path as an invocation. On Spec Kit extension installs, resolve a capability `<capability>` to the registered `speckit.architecture-guard.ag-<capability>` command file in the agent's command directory, or to `.specify/extensions/architecture-guard/commands/<capability>.md`.

## Input & Context Loading

Before refining governance, read these inputs explicitly with file-reading tools:

1. **Manifest & Configuration**: Read `openspec/config.yaml` first when the OpenSpec adapter is active (otherwise read the selected adapter project configuration), then inspect its `context` block for every referenced governance and constitution Markdown file. Never rely on a hardcoded partial list.
2. **Authoritative Constitutions (read all that exist)**: Read every declared or present governance, constitution, architecture, security, and layout Markdown file. For OpenSpec, explicitly check `openspec/constitution.md`, `openspec/architecture.md`, `openspec/security.md`, and `openspec/layout.md`. For SpecKit, use the adapter-resolved `.specify/memory/constitution.md`, `.specify/memory/architecture_constitution.md`, `.specify/memory/security_constitution.md`, and any adapter-defined layout constitution. Never silently omit an existing file.
3. **Initialization Artifacts**: Read any constitution draft, existing governance configuration, and framework preset required by this skill.

This command helps teams intentionally define:

* engineering governance principles
* architecture boundaries
* enforcement standards
* validation and contract rules
* architecture evolution policies

This command generates or refines:

* `.specify/memory/constitution.md`
* `.specify/memory/architecture_constitution.md`
* `.specify/memory/security_constitution.md`
* optional `.specify/config/architecture_guard.yml` context-loading configuration

## Workflow Integration

Run this command once per project or whenever the constitution files need refinement. If the constitution files already exist, refine them instead of starting over.

See the README quick start for brownfield and greenfield entrypoints.

After init, the usual next step is `/speckit.architecture-guard.ag-governed-plan` or `/speckit.architecture-guard.ag-governed-tasks`, depending on whether the team wants planning or task generation next.

When Flash-Mem is available, prefer it first for retrieving prior decisions, summaries, and existing constitution context. The repository files remain the source of truth for constitution content, and the legacy `memory-hub` name is reference-only and should not be treated as the runtime backend. If Flash-Mem is unavailable or the context is incomplete, resolve the selected project configuration first (`openspec/config.yaml` for OpenSpec), inspect its `context` block for every referenced governance and constitution Markdown file, then explicitly read every declared or present constitution, architecture, security, and layout Markdown file and treat those repository files as the canonical source of truth. For OpenSpec, check `openspec/constitution.md`, `openspec/architecture.md`, `openspec/security.md`, and `openspec/layout.md`; for other adapters, read every corresponding path resolved by the adapter path map, including any layout or UI constitution path. Never silently omit an existing file. After refining the constitutions, propose durable summaries and major decisions for Flash-Mem, show the exact entries, and write them only after explicit user approval.

The goal is NOT to generate generic best practices.

The goal is to establish:

* enforceable rules
* clear boundaries
* long-term consistency
* architecture evolution discipline
* project-specific standards

---

## Framework-Agnostic vs Framework-Aware

**Framework-Agnostic Core** (applied to all projects):
- Universal boundary concepts apply (Entry, App, Domain, Data, External)
- Core governance principles are framework-independent
- Examples: "Domain logic never touches HTTP", "Persistence is abstracted", "Events flow one direction"

**Framework-Aware Enhancement** (optional, selected during init):
- If user selects framework preset (Laravel, Django, NestJS, etc.):
  - Core principles are enhanced with framework-specific vocabulary
  - Examples become Laravel-idiomatic, Django-idiomatic, etc.
  - Pattern names shift from generic to framework-native
  - But underlying boundary concepts remain identical

**Coexistence**:
- Command starts technology-agnostic
- If preset selected: Constitution gains framework-aware guidance
- Both layers work together: abstract principles + concrete framework patterns
- Switching frameworks: Start over, preset vocabulary changes but core governance remains

---

# Core Principles

## 1. Sequential Interviewing

DO NOT ask all questions at once.

Interview the user in logical phases.

Only continue when the current phase is sufficiently understood.

---

## 2. Context-Aware Guidance

Adapt vocabulary and suggestions based on:

* framework
* architecture style
* project maturity
* existing conventions
* existing constitution files

Examples:

* Laravel → Controllers, Form Requests, Actions, Eloquent
* NestJS → Controllers, Providers, DTOs, Modules
* Next.js → Server Components, Server Actions, Zod
* Nuxt → Composables, Pinia, server/api
* React Native → Screens, hooks, navigation, device services, native modules

---

## 3. Suggestions, Not Forced Opinions

Reference patterns are suggestions.

NEVER force architecture opinions into the Constitution.

A rule only becomes a standard when:

* the user explicitly accepts it
* OR the project already consistently follows it

---

## 4. Architecture Before Implementation

Prioritize:

* boundaries
* ownership
* responsibilities
* contracts
* dependency direction

before implementation details.

---

## 5. Explicit Standards Only

Avoid vague guidance.

BAD:

```text
Follow best practices
```

GOOD:

```text
Controllers must delegate business logic to Services or Actions.
```

---

## 6. Constitution Changes Must Be Intentional

NEVER automatically evolve architecture direction.

If architecture drift is detected:

* summarize the drift
* explain impact
* propose evolution
* require explicit approval

---

## 7. Layered Constitution Strategy

This system separates:

* governance principles
* architecture enforcement rules

The system must maintain:

* `.specify/memory/constitution.md`
* `.specify/memory/architecture_constitution.md`

Avoid duplication between both files.

---

## 8. Graceful Exit and Resume Flow

Users may need to pause the init workflow and resume later. Support this gracefully:

**Pausing Mid-Interview**:
1. Ask user: "Do you want to save these answers to `.specify/memory/constitution-draft.md` and resume later? [y/N]" and preview the draft path and contents (answers, timestamp, completion percentage). Do not write anything before the answer.
2. If YES: write the draft only then, and exit cleanly with resume instructions
3. If NO or no answer: write nothing, discard the in-session answers, and suggest next steps

**Resuming Saved Draft**:
1. Detect `.specify/memory/constitution-draft.md` on next init run
2. Ask: "I found a draft from [timestamp]. Resume from where you left off?"
3. If YES: Load saved answers, continue from last question
4. If NO: Start fresh without modifying the old draft. Archive, move, or delete the old draft only if the user explicitly approves that exact operation (show the source and target paths, `[y/N]`); otherwise leave it in place

**Draft Contents**:
```yaml
# Constitution Draft (Paused)
timestamp: 2025-01-15T14:30:00Z
completion: "Phase 1/3 (Framework + Team)"
framework: [answer if provided]
team_size: [answer if provided]
technology_stack: [answer if provided]
architecture_guard_context_mode: [targeted or budgeted if answered]
# ... other captured answers
```

---

# Constitution Responsibilities

---

## `.specify/memory/constitution.md`

Purpose:

High-level governance and engineering philosophy.

Should contain:

* engineering philosophy
* pragmatism & simplicity (Ponytail principles: YAGNI, standard library preference, lazy senior developer mindset)
* testing standards
* security expectations
* documentation standards
* review expectations
* operational expectations
* high-level architecture intent

Should NOT contain:

* controller implementation details
* DTO implementation specifics
* framework-specific structure rules
* module folder naming conventions

---

## `architecture_constitution.md`

Purpose:

Enforceable architecture standards and system boundaries.

Should contain:

* layer boundaries
* business logic placement
* validation flow
* DTO/schema standards
* module ownership rules
* async boundaries
* API contract rules
* framework-specific architectural conventions
* architecture evolution rules

---

## `security_constitution.md`

Purpose:

Project-wide security rules, standards, and requirements.

Should contain:

* trust boundaries
* authentication/authorization standards
* secret management policies
* data isolation rules
* audit/logging requirements
* secure-by-design patterns

---

# Initialization Logic

## Step 1 — Detect Existing Constitution Files

Before assessing the existing state, read the selected adapter project configuration first (`openspec/config.yaml` for OpenSpec), inspect its `context` block for every referenced governance and constitution Markdown file, and explicitly read every declared or present governance, constitution, architecture, security, and layout Markdown file. For OpenSpec, check `openspec/constitution.md`, `openspec/architecture.md`, `openspec/security.md`, and `openspec/layout.md`; for SpecKit, use the adapter-resolved constitution files under `.specify/memory`. Never silently omit an existing file.

Check for:

* `.specify/memory/constitution.md`
* `.specify/memory/architecture_constitution.md`
* `.specify/memory/security_constitution.md`

---

## Existing-State Rules

| Existing state | Behavior |
|---|---|
| All three exist | Summarize governance, architecture, security, conflicts, and duplication; offer targeted refinement. |
| Governance + architecture exist | Preserve both; offer embedded security rules or creation of the security constitution. |
| Governance + security exist | Preserve both; offer embedded architecture rules or creation of the architecture constitution. |
| Architecture + security exist | Preserve both; offer creation of the governance constitution before any restructuring. |
| Governance only | Analyze embedded architecture/security rules and offer dedicated files. |
| Architecture only | Preserve it and offer governance plus security coverage. |
| Security only | Preserve it and offer governance plus architecture coverage. |
| None exist | Start the phased initialization interview. |

Never describe a partial state as fully initialized. Preview exact target files and proposed ownership changes, obtain explicit approval before writing, and never overwrite existing rules automatically.

---

# Interview Flow

---

# Phase 1 — Project Identity & Architecture Style

Determine:

* technology stack
* architecture style
* runtime boundaries
* application type
* deployment shape

---

## Questions

### Technology Stack

Ask:

```text
What is the primary technology stack?

Examples:
- Laravel 12 + Inertia React
- NestJS 10
- Next.js 15 App Router
- Nuxt 3
- Express + React
- React Native + Expo
```

### Framework Preset

If the technology stack matches a built-in preset (e.g., Angular, Laravel, NestJS, Next.js, Nuxt.js, Django, Spring Boot, React, React Native, Vue, or Express), ask:

```text
Would you like to use the [Framework] Architecture Preset?

This will:
1. Configure the engine to be [Framework]-aware.
2. Use framework-specific knowledge during constitution generation.
3. Provide specialized detection for [Framework] anti-patterns.
```

---

### Architecture Style

Ask:

```text
What architecture style does this project follow?

- Monolith
- Modular Monolith
- Microservices
- Event-Driven
- Hybrid
```

---

### Application Type

Ask:

```text
What type of application is this?

Examples:
- REST API
- Full-stack web app
- Internal dashboard
- Public SaaS
- Realtime platform
- Background processing system
```

---

### Delivery Topology (Solo vs Team vs Agent Teams)

Ask:

```text
How will development be delivered on this project?

- Solo Development (Single developer / AI pair)
- Team Development (Human team with Issue Tracker sync)
- Claude Code Agent Teams (Autonomous 6-role agent team: Analyst Creator, Analyst Reviewer, BE, FE, Unit Test, Code Reviewer)
```

If the user selects Team Development:
1. Ask: "Which issue tracker MCP server should be used to sync User Stories? (e.g., github-mcp-server, jira, none)".
2. If an issue tracker is selected (not "none"), ask for the required provider configuration (e.g., `repo` string for GitHub or `project` string for Jira).
3. Preview the exact proposed governance changes and team scaffolding, including `Mode: Team`, the tracker preference, `user-stories/`, and `.architecture-guard/sync.yml` when applicable.
4. Require explicit user approval of that preview before writing governance rules or creating any team scaffolding. If approval is declined, make no team-mode writes.

If the user selects Claude Code Agent Teams:
1. Preview the proposed Architecture Guard role profile by reading `.specify/extensions/architecture-guard/templates/agents_template.yml` (or `templates/agents_template.yml` in the extension source checkout). This legacy Spec Kit command is self-contained and does not require the standalone `architecture-guard` CLI.
2. Explain that the profile is not a native Claude Code configuration file; current Claude Code uses an implicit team and named teammate spawning.
3. Include creation of `.architecture-guard/agents.yml` and the exact constitution changes in the write preview, then require explicit approval before either write.
4. After approval, set `topology: claude-code-agent-teams`, record role boundaries in `.specify/memory/constitution.md`, and write the profile.
5. Note that Agent Teams also requires host support and `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1`. Fall back to single-agent execution when either is absent.

---

### Architecture Context Budget

After the project shape is understood, ask:

```text
Would you like Budgeted Architecture Context Retrieval?

- Targeted (default): preserve the existing Flash-Mem-first workflow.
- Budgeted: cap initial Flash-Mem retrieval, use specs/system_context.md only when memory is unavailable or insufficient, and open historical specs only for named gaps.

Budgeted mode is mainly useful when a repository has many historical feature specs. It does not replace active feature artifacts and does not guarantee savings until benchmarked on this project.
```

If the user selects Budgeted:

1. Create `.specify/config/architecture_guard.yml` from `.specify/extensions/architecture-guard/templates/architecture_guard_config.yml` (or `templates/architecture_guard_config.yml` in the extension source checkout).
2. Set `context.mode: budgeted`.
3. Preserve the default retrieval limits unless the user explicitly requests different limits.
4. If feature specs already exist, run `/speckit.architecture-guard.ag-consolidate-specs` after constitution generation is complete.

If the user selects Targeted or gives no answer, preserve existing behavior. Do not add operational context settings to any constitution.

Repository hygiene policy is separate from context settings. `architecture-guard hygiene` does not read `.specify/config/architecture_guard.yml`; when the user wants a hygiene policy (`enabled`, `fail_on`, `warn_on`, `ignore`), write it as a top-level `repository_hygiene:` block in `.specify/config/repository_hygiene.yml`, using the commented example in the config template. Preview it in the write approval like every other generated file.

---

# Architecture-Aware Branching

---

## If Monolith

Focus on:

* layering
* separation of concerns
* entry-point discipline

---

## If Modular Monolith

Focus on:

* module ownership
* cross-module access
* shared contracts
* dependency direction

---

## If Microservices

Focus on:

* service ownership
* API contracts
* event communication
* shared database restrictions
* service boundaries

---

# Framework Preset Interview

Framework-specific questions belong to the selected preset, not this command.

When the user selects a built-in framework preset:

1. Resolve its preset file from `.specify/extensions/architecture-guard/presets/[preset].md`. In the extension source checkout, use `presets/[preset].md`.
2. Locate `## Init Interview` and read that section through the next level-two heading. Do not load unrelated review guidance solely to run the interview when the host can read a section selectively.
3. Merge the preset questions into the matching generic interview phases. Ask them sequentially and only when relevant to the selected application type or an earlier answer; do not ask a generic and preset question twice when they seek the same decision.
4. Record each answer as a framework-neutral architectural decision plus its selected framework implementation.
5. If the preset has no `## Init Interview` section, continue with the generic phases below without inventing framework requirements.

Keep the normalized decisions portable, including use-case invocation style, DTO strategy, authorization strategy, validation, contracts, and boundary ownership. Package-specific options MUST remain inside the matching preset. Selecting a package records a convention; it does not authorize init to install dependencies.

If the user selects no enforced convention, preserve that choice and do not turn the preference into an architecture violation.

---

# Phase 2 — Business Logic & Boundaries

Determine:

* business logic ownership
* dependency direction
* layer responsibilities
* boundary isolation

---

## Questions

Ask:

```text
Where should business logic live?
```

---

Ask:

```text
Which layers may communicate directly?
```

---

Ask:

```text
Should the domain layer remain isolated from transport layers such as HTTP, queues, or UI?
```

---

Ask:

```text
How strict should module boundaries be enforced?
```

---

# Phase 3 — Contracts & Validation

Determine:

* validation strategy
* request/response contracts
* serialization standards
* frontend/backend boundaries

---

## Questions

Ask:

```text
How should input validation be handled?
```

---

Ask:

```text
What is the standard response structure?
```

---

## Preset Contract Questions

If the selected preset's `## Init Interview` includes contract or validation questions, ask them during this phase unless an earlier answer already resolves them. Do not ask the same question twice.

---

# Phase 4 — Data Access & Async Rules

Determine:

* ORM strategy
* repository usage
* query ownership
* async boundaries
* background processing rules

---

## Questions

Ask:

```text
How should data access be handled?

Examples:
- direct ORM usage
- repositories
- query services
- domain repositories
```

---

Ask:

```text
When should async processing be required?
```

---

Ask:

```text
Which operations must never block requests?
```

---

# Phase 5 — Naming & Namespacing Conventions

Determine:

* class naming standards
* property naming standards
* module and folder naming conventions

---

## Questions

Before asking detailed questions, ask:

```text
Do you want to use standard/general naming conventions, or detailed custom conventions?

- Standard/General: The system will use preset defaults (if a framework is selected) or common defaults.
- Detailed Custom: The system will ask specific questions about your naming standards.
```

If the user selects Standard/General and a framework preset is active, use the preset's `## Naming Standards` to automatically configure the rules. If the active preset does not explicitly define a `## Naming Standards` section, automatically apply the universally accepted general native naming conventions for that programming language (e.g., PEP-8 for Python, standard Java conventions for Spring, standard PHP PSR-4 conventions, etc.). If no preset is active, use common defaults (e.g., PascalCase for classes, camelCase for properties).

If the user selects Detailed Custom, ask:

```text
What are the naming conventions for:
- Classes (e.g., Adapters, Controllers, Services)?
- Properties (props)?
- Folder structures?
```

---

# Phase 6 — Enforcement & Evolution

Determine:

* blocking rules
* architecture governance
* evolution policies
* intentional deviations

---

## Questions

Ask:

```text
Which rules should be treated as blocking violations (P0)?
```

---

Ask:

```text
Are there intentional architectural deviations that should be documented?
```

---

Ask:

```text
How should architecture evolution be handled?

Examples:
- manual review only
- proposal-based evolution
- strict governance
```

---

## Final Confirmation

At the end of the initialization interview, before generating or updating the constitution files, you MUST ask the user:

```text
Do you have any concerns related to the current rules?
```
Wait for the user's confirmation to ensure they are aware of the generated configuration and ready to finalize.

---

# Rule Classification Logic

Before generating rules, classify them.

---

## Global Governance Rules → `.specify/memory/constitution.md`

Examples:

* testing philosophy
* documentation standards
* security requirements
* review expectations
* engineering philosophy (Ponytail principles, YAGNI, minimal abstractions)
* operational governance

---

## Architecture Enforcement Rules → `.specify/memory/architecture_constitution.md`

Examples:

* controller/service boundaries
* DTO requirements
* use-case invocation style and its framework implementation, when selected
* DTO strategy and its framework implementation, when selected
* authorization strategy and its framework implementation, when selected
* validation placement
* async boundaries
* response contracts
* module ownership rules
* framework-specific architecture patterns
* DRY and single-source-of-truth rules for repeated business rules, approvals, validation, DTO mapping, transformations, and orchestration
* temporary/scratch files MUST use `-temp` or `-test` suffixes for easier cleanup

---

# Duplication Prevention Rules

DO NOT duplicate rules across both files.

If a rule exists in:

```text
.specify/memory/architecture_constitution.md
```

Then:

```text
.specify/memory/constitution.md
```

should reference architecture rules instead of repeating implementation details.

---

GOOD:

```text
.specify/memory/constitution.md:
- Architecture enforcement rules are defined in `.specify/memory/architecture_constitution.md`
```

```text
.specify/memory/architecture_constitution.md:
- Controllers must delegate business logic to Services or Actions
```

---

BAD:

Duplicating detailed architecture rules in both files.

---

# Constitution Synthesis Rules

DO NOT generate final documents until:

* enough information has been collected
* OR the user explicitly requests a draft

Before creating, modifying, deleting, moving, or scaffolding any file or directory, show the exact target paths and proposed operations and obtain explicit user approval.

---

# Output Requirements

Generate or refine:

* `.specify/memory/constitution.md`
* `.specify/memory/architecture_constitution.md`
* `.specify/memory/security_constitution.md`

When Budgeted Architecture Context Retrieval is selected, also generate `.specify/config/architecture_guard.yml`. Missing configuration means targeted mode, preserving backward compatibility.

When the user requests a repository hygiene policy, also generate `.specify/config/repository_hygiene.yml` with a top-level `repository_hygiene:` block.

If the `flash-mem` MCP server is available, propose `update_project_summary` for major changes in architecture, boundaries, or governance rules and execute it only after explicit user approval. If it is unavailable, rely on the repository files directly and continue without the sync step.

---

## `.specify/memory/constitution.md` Structure

```text
1. Project Identity
2. Engineering Philosophy
3. Security Expectations
4. Testing Expectations
5. Documentation Standards
6. Review Process
7. High-Level Architecture Intent
8. Naming & Namespacing Conventions
9. Governance and Evolution Policy
```

---

## `.specify/memory/architecture_constitution.md` Structure

```text
1. Architecture Style
2. Layer Boundaries
3. Business Logic Placement
4. Contracts & Validation
5. Data Access Rules
6. Async & Integration Rules
7. Module Boundaries
8. Naming & Namespacing Conventions
9. Framework-Specific Architecture Rules
10. Blocking Architecture Violations (P0)
11. Architecture Evolution Policy
12. Refactor & Drift Handling
```

---

## `.specify/memory/security_constitution.md` Structure

```text
1. Trust Boundaries
2. Authentication & Authorization Standards
3. Data Isolation & Privacy Rules
4. Secrets Management Policy
5. Secure-by-Design Patterns
6. API & Integration Security
7. Audit, Logging & Monitoring Requirements
8. Security Incident Response Triggers
9. Compliance & Regulatory Mapping
```

---

# Architecture Evolution Rules

Architecture rules may evolve over time.

When repeated architecture drift is detected:

* generate Constitution Update Proposals
* target `.specify/memory/architecture_constitution.md` by default
* only propose updates to `.specify/memory/constitution.md` for governance-level changes

NEVER automatically modify either file.

---

# Preset Reference Patterns

Framework-specific reference patterns belong to the selected preset. Use them as optional guidance while interpreting interview answers, but do not automatically enforce them or copy unselected patterns into the Constitution.

---

# Final Rules

This command exists to help teams intentionally design:

* governance standards
* architecture boundaries
* evolution policies
* enforceable engineering systems

It must NOT:

* generate vague advice
* blindly enforce trends
* automatically rewrite architecture direction
* duplicate rules across constitutions
* duplicate business rules, approvals, validation, DTO mapping, transformations, or orchestration across modules or layers

The generated constitutions must reflect intentional engineering decisions.
