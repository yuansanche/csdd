---
description: Generate a compact, non-authoritative local fallback index from feature specifications.
---

# Consolidate Specs Command

## SDD Adapter Resolution

Before executing this command, read `.architecture-guard/adapters/resolve.md` and resolve the adapter with its chain (explicit `--adapter` override, `.architecture-guard/selected-adapter`, `.architecture-guard/config.yml`, then filesystem markers), then load `.architecture-guard/adapters/{tool}.md` for path maps, command maps, and gap fills. Stop with `Unavailable` and the exact path if the adapter file is missing. Do not use the Architecture Guard resource resolver for adapter selection: adapter files are not a `resolve` resource category. Resolve every adapter path and command token before continuing; all paths and commands below use the loaded adapter.

## Standalone Resource Resolution

Architecture Guard engine resources are standalone package resources. Never search an SDD-tool directory, an extension directory, or a source checkout for them. An adapter path under `.architecture-guard` is an editable local override location, not proof that the resource was copied.

- Directly inspect the matching `.architecture-guard/<category>/` directory first for workspace overrides.
- If the named local resource exists, read it. Otherwise run `architecture-guard resolve <category> <name>` and use the returned content.
- For a resource collection, run `architecture-guard resolve <category> --list`, then resolve every returned name individually in deterministic order so local overrides replace bundled files without hiding bundled defaults.
- If the CLI is unavailable and a mandatory resource is not vendored locally, stop and report the missing runtime dependency. For optional resources, report `Unavailable` and continue only when this command explicitly permits degradation.

## Ponytail Core Contract

Before continuing, you **MUST** resolve and apply the `ponytail_core` template with `architecture-guard resolve template ponytail_core` as the authoritative shared contract. Phase instructions may narrow but not weaken its safety or verification floor.

## Capability Composition

Resolve and apply the `capability_composition` template with `architecture-guard resolve template capability_composition` before delegating to another Architecture Guard capability. Resolve and read the installed sibling skill or command file directly; do not treat a capability name or Markdown path as an invocation.

## Input & Context Loading

Before making decisions or delegating work, read these inputs explicitly with file-reading tools:

1. **Manifest & Configuration**: Read the selected adapter's project configuration (`{adapter_path:project-config}`) first, then inspect it for references to further governance and constitution Markdown files (for example a `context` block). Never rely on a hardcoded partial list.
2. **Authoritative Constitutions (read all that exist)**: Read every declared or present governance, constitution, architecture, security, and layout Markdown file. Explicitly check {adapter_path:constitution-set} when present, plus every corresponding path resolved by the adapter path map, including any layout or UI constitution path. Never silently omit an existing file.
3. **Active Artifacts**: Read the feature, review, plan, task, or current-state artifacts required by this skill.

## Purpose

Provide the adapter's compact offline fallback for Budgeted Architecture Context Retrieval. It supplements active artifacts and never replaces them.

## Procedure

1. Resolve {adapter_command:consolidate-specs} and `{adapter_path:fallback-spec-index}`.
2. If consolidation is unsupported, execute {adapter_command:list-specs}, return that adapter-native index, and do not write a fallback artifact. Otherwise follow {adapter_command:consolidate-specs} only to build the fallback content in memory: enumerate `{adapter_path:spec}` in normalized path order, excluding the fallback, generated artifacts, and explicitly archived sources. Steps 2–6 are read-only; nothing is written to the fallback index or any other path before the step 6 confirmation.
3. If no source specs exist, report that no fallback was generated and leave any existing fallback untouched unless the user explicitly authorizes replacing it.
4. Read each source only far enough to extract its title or one-line purpose, requirement and acceptance-criteria identifiers, shared invariants, cross-feature dependencies, and explicit conflicts. Acceptance-criteria bodies remain in the source spec.
5. Deduplicate only statements that are clearly identical. Keep similar statements separate. Never resolve conflicts or ambiguity silently.
6. **Confirm before writing**: Show the resolved output path, whether it creates or replaces an existing fallback, and a summary of the generated entries. Request explicit confirmation. If the user declines or does not confirm, return the generated content and source manifest without writing, and stop.
7. Only after explicit confirmation, write the complete generated artifact in one operation (this is the only write this command performs) with the structure below. Keep feature entries to one line plus identifiers and provenance so the fallback does not become another full specification.

## User Interaction and Result

In Generic workflow mode, ask the user for source specification paths and the desired fallback output path when the adapter cannot resolve them. Writing or replacing a fallback always requires the confirmation in step 6. A decline or unsupported consolidation returns the available adapter-native index or source manifest without writing.

## Required Output

```markdown
# Generated System Context

> Generated by Architecture Guard. This non-authoritative fallback supplements active feature artifacts and must not replace them.

## Generation Metadata
- Generated At: [ISO-8601 timestamp]
- Source Count: [count]

## Shared System Invariants
- [Concise invariant with source paths]

## Feature Index
- **[Feature]** — [One-line purpose]; IDs: [requirement/acceptance IDs]; Source: [adapter-resolved spec path]

## Cross-Feature Dependencies
- [Dependency with source paths]

## Unresolved Conflicts and Ambiguities
- [Distinct statements and their source paths; use `None identified` when empty]

## Source Manifest
- [adapter-resolved spec path]
```

## Completion Report

Report status (`Generated`, `Declined`, `Unsupported`, `No Sources`, or `Partial`), output path, source count, conflicts found, excluded or unreadable sources, and whether regeneration was complete. Do not claim exact token savings; those require representative benchmark runs.

## Next-Step Handoff

Return the adapter-resolved fallback path when generated, or the returned index/manifest otherwise, as the context input for the next review or planning command. Preserve unresolved conflicts verbatim so the receiving workflow can request a decision rather than treating the fallback as authoritative.
