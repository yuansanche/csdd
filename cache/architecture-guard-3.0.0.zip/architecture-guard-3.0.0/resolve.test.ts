import { test } from 'node:test';
import assert from 'node:assert';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { resolveResource, listCategoryResources } from './cli/resolve';

test('resolves bundled template ponytail_core', () => {
  const result = resolveResource('template', 'ponytail_core');
  assert.strictEqual(result.source, 'bundled');
  assert.strictEqual(result.category, 'templates');
  assert(result.content.includes('# Ponytail Core Contract'));
  assert(fs.existsSync(result.path));
});

test('resolves bundled preset backend/laravel/django/etc', () => {
  const result = resolveResource('preset', 'laravel');
  assert.strictEqual(result.source, 'bundled');
  assert.strictEqual(result.category, 'presets');
  assert(result.content.length > 0);
});

test('resolves bundled sonar rules by default without name', () => {
  const result = resolveResource('sonar-rules');
  assert.strictEqual(result.source, 'bundled');
  assert.strictEqual(result.category, 'sonar-rules');
  assert(result.name.includes('sonarlint-rules.json'));
});

test('prioritizes local workspace override when present', () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ag-resolve-test-'));
  try {
    const localTemplatesDir = path.join(tmpDir, '.architecture-guard', 'templates');
    fs.mkdirSync(localTemplatesDir, { recursive: true });
    const customContent = '# Custom Ponytail Override\nCustom contract content';
    fs.writeFileSync(path.join(localTemplatesDir, 'ponytail_core.md'), customContent);

    const result = resolveResource('template', 'ponytail_core', { target: tmpDir });
    assert.strictEqual(result.source, 'local');
    assert.strictEqual(result.content, customContent);
    assert.strictEqual(result.path, path.join(localTemplatesDir, 'ponytail_core.md'));
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});

test('resolves manifest config.yml from local workspace', () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ag-resolve-manifest-test-'));
  try {
    const agDir = path.join(tmpDir, '.architecture-guard');
    fs.mkdirSync(agDir, { recursive: true });
    const configContent = 'adapter: openspec\npresets:\n  - backend\n';
    fs.writeFileSync(path.join(agDir, 'config.yml'), configContent);

    const result = resolveResource('manifest', undefined, { target: tmpDir });
    assert.strictEqual(result.source, 'local');
    assert.strictEqual(result.name, 'config.yml');
    assert.strictEqual(result.content, configContent);
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});

test('rejects path traversal attempts (CWE-22)', () => {
  assert.throws(() => {
    resolveResource('template', '../../etc/passwd');
  }, /path traversal detected/);

  assert.throws(() => {
    resolveResource('preset', '../something');
  }, /path traversal detected/);
});

test('lists available resources in category', () => {
  const presets = listCategoryResources('preset');
  assert(presets.length > 0);
  assert(presets.includes('laravel.md') || presets.includes('django.md'));
});

test('lists bundled resources and deduplicated workspace overrides', () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ag-resolve-list-'));
  try {
    const localRulesDir = path.join(tmpDir, '.architecture-guard', 'hygiene-rules');
    fs.mkdirSync(localRulesDir, { recursive: true });
    fs.writeFileSync(path.join(localRulesDir, 'temporary-files.md'), '# Local override\n');
    fs.writeFileSync(path.join(localRulesDir, 'project-only.md'), '# Project rule\n');

    const resources = listCategoryResources('hygiene-rules', { target: tmpDir });
    assert(resources.includes('temporary-files.md'));
    assert.equal(resources.filter(name => name === 'temporary-files.md').length, 1);
    assert(resources.includes('project-only.md'));
    assert(resources.includes('duplicate-business-logic.md'));
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});


test("keeps adapter selection out of engine resource resolution", () => {
  assert.throws(() => resolveResource("adapter"), /Adapter selection is file-based/);
  assert.throws(() => listCategoryResources("adapter"), /Adapter selection is file-based/);
});

test('resolves bundled flow template default', () => {
  const result = resolveResource('flow', 'default');
  assert.strictEqual(result.source, 'bundled');
  assert.strictEqual(result.category, 'flow');
  assert(result.content.includes('# SDD Flow Template'));
  assert(fs.existsSync(result.path));
});

test('prioritizes local flow override when present', () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ag-resolve-flow-test-'));
  try {
    const localFlowDir = path.join(tmpDir, '.architecture-guard', 'flow');
    fs.mkdirSync(localFlowDir, { recursive: true });
    const customContent = '# Custom Flow Override\nCustom single-file layout';
    fs.writeFileSync(path.join(localFlowDir, 'default.md'), customContent);

    const result = resolveResource('flow', 'default', { target: tmpDir });
    assert.strictEqual(result.source, 'local');
    assert.strictEqual(result.content, customContent);
    assert.strictEqual(result.path, path.join(localFlowDir, 'default.md'));
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});

test('lists available flow templates', () => {
  const flows = listCategoryResources('flow');
  assert(flows.length > 0);
  assert(flows.includes('default.md'));
});

test('rejects path traversal attempts for flow category', () => {
  assert.throws(() => {
    resolveResource('flow', '../../etc/passwd');
  }, /path traversal detected/);
});

test('resolves bundled generic artifact templates', () => {
  for (const name of ['generic_spec', 'generic_plan', 'generic_tasks']) {
    const res = resolveResource('template', name);
    assert.strictEqual(res.source, 'bundled');
    assert(res.content.length > 0);
  }
});
